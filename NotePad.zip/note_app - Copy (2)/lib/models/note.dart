class Note {
  int id;
  String title;
  String content;
  DateTime modifiedTime;

  Note({
    required this.id,
    required this.title,
    required this.content,
    required this.modifiedTime,
  });
}


List<Note> sampleNotes = [
  Note(
    id: 0,
    title: 'note11',
    content:
        'Project Ini Dalam Proses',
    modifiedTime: DateTime(2023,1,1,34,5),
  ),
  Note(
    id: 1,
    title: 'Kelompok NotePad',
    content:
        '1. Raka Trisnaldy Faturrahman (Hacker)\n2. Felix Rafael Pangabean (Leader)\n3. Jay Davershane (Design)',
    modifiedTime: DateTime(2022,1,1,34,5),
  ),
  Note(
    id: 2,
    title: 'tes',
    content:
        'testing',
    modifiedTime: DateTime(2023,3,1,19,5),
  )
];
